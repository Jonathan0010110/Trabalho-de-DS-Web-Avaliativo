package com.Jonathan.Tabalho_de_Carlos.Controller;
import com.Jonathan.Tabalho_de_Carlos.domain.User;
import com.Jonathan.Tabalho_de_Carlos.service.BatataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/Trabaio")




public class QIExecivoController {
    @Autowired
    private BatataService batataService;

    @GetMapping
    public String genial(){
        return batataService.batatoso("Jonathan");

    }

    @PostMapping("/{id}")
    public String postagem(@RequestParam(value ="bagunceiro", defaultValue = ("Ninguém")) String aquele,@PathVariable("id") String pessoa,@RequestBody User body){
        return "Esse testo é Post feito por " + body.getNome() + " e essa pessoa tá mexendo na API(adicione na url: /seunome): " + pessoa + " e essa pessoa tá bagunçando(depois do seu nome adicone: /?bagunceiro=nome): " + aquele;
    }


}
