package com.Jonathan.Tabalho_de_Carlos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TabalhoDeCarlosApplication {

	public static void main(String[] args) {
		SpringApplication.run(TabalhoDeCarlosApplication.class, args);
	}

}
