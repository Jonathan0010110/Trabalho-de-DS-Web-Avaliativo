package com.Jonathan.Tabalho_de_Carlos.configuration;


import org.springframework.context.annotation.Configuration;

@Configuration
public class NomeCriativoConfiguration {
}
