package com.Jonathan.Tabalho_de_Carlos.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class User {
    private String nome = "Carlos";
}
