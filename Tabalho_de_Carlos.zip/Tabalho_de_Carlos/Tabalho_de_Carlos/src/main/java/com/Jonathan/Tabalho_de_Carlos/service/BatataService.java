package com.Jonathan.Tabalho_de_Carlos.service;

import org.springframework.stereotype.Service;

@Service
public class BatataService {

    public String batatoso(String name){
        return "criador: "+ name;
    }
}
