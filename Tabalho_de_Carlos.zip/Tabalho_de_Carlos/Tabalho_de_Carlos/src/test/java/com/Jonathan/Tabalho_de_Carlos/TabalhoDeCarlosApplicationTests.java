package com.Jonathan.Tabalho_de_Carlos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TabalhoDeCarlosApplicationTests {

	@Test
	void contextLoads() {
	}

}
